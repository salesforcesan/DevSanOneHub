(function() {
    var _app = window["ShoppingEvent.crossmark.com"].getApplication(),
        _async = _app.Async;


    var Model = function() {
        var self = {};

        function getIdNameMappings() {
            return [{
                from: "Id",
                to: "key"
            }, {
                from: "Name",
                to: "value"
            }];
        }

        //doto: doesn't support INTL. if project type name is changed, this code need to change; otherwise not working.
        self.getCreateProjectUI = function(projectType) {
            console.log(projectType);
            var url = (projectType.toLowerCase().indexOf("road show") !== -1) ? "/assets/templates/project.create.roadshow.html" : "/assets/templates/project.create.storedemo.html";
            return _app.Http.getHtml(_app.Resources.appPath + url);
        };

        self.getRetailers = function(name) {
            var fieldMaps = getIdNameMappings(),
                retailers = new SObjectModel.Retailer__c();
            return _async.call(retailers.retrieve, "", fieldMaps);
        };

        self.getClients = function(name) {
            var fieldMaps = getIdNameMappings(),
                clients = new SObjectModel.Client__c();
            return _async.call(clients.retrieve, "", fieldMaps);
        };

        self.getApprovers = function(name) {
            var fieldMaps = getIdNameMappings(),
                approvers = new SObjectModel.User();
            return _async.call(approvers.retrieve, "", fieldMaps);
        };

        self.saveProject = function(formData) {
            var project = new SObjectModel.Project__c();
            console.log(project);
            project.set("ProjectType__c", formData.typeId);
            project.set("Retailer__c", formData.retailerId);
            project.set("Name", formData.title);
            project.set("Client__c", formData.clientId);
            project.set("StartDate__c", formData.startDate);
            project.set("EndDate__c", formData.endDate);
            project.set("Budgeted_Locations__c", formData.budgetLocations);
            project.set("Approver1__c", formData.approverId);
            project.set("Overview__c", formData.description);
            project.set("NumberOfDays__c", formData.days);
            project.set("NumberOfPallets__c", formData.pallets);
            project.set("ResponsibleForExecution__c", "Execution Company");

            return _async.call(project.create, "", []);
        }

        return self;
    };

    function flipDashboardAndFormWizard() {
        $("#dashboard").toggleClass('cm-hide');
        $("#formWizard").toggleClass('cm-hide');
    }

    function toDateUTC(dateString) {
        var date = new Date(dateString);
        return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
    }

    var Viewer = function() {
        var _self = Object.create(_app.createView()),
            _templates = [],
            _retailerLookupMenu = _app.UI.lookupMenu({
                containerId: "projectRetailerLookup"
            }),
            _clientLookupMenu = _app.UI.lookupMenu({
                containerId: "projectClientLookup"
            }),
            _approverLookupMenu = _app.UI.lookupMenu({
                containerId: "projectApproverLookup"
            });

        _self.getFormData = function() {
            return {
                id: "",
                typeId: $(".cm-form-wizard").attr("data-type-id"),
                retailerId: $(".cm-form-wizard #projectRetailer").attr("data-id"),
                clientId: $(".cm-form-wizard #projectClient").attr("data-id"),
                approverId: $(".cm-form-wizard #projectApprover").attr("data-id"),
                startDate: toDateUTC($(".cm-form-wizard #projectStartDate").val()),
                endDate: toDateUTC($(".cm-form-wizard #projectEndDate").val()),
                budgetLocations: $(".cm-form-wizard #projectBudgetLocations").val(),
                days: 11,
                pallets: $(".cm-form-wizard #projectPallets").val(),
                description: $(".cm-form-wizard #projectDescription").val()
            };
        };

        _self.validateFormData = function() {
            return 1;
        };

        _self.uiLoaded = function(projectTypeId) {
            var index = _.findIndex(_templates, function(t) {
                return t.id === projectTypeId;
            });
            return (index === -1) ? 0 : 1;
        };

        _self.setUI = function(projectTypeId, html) {
            _templates.push({
                id: projectTypeId,
                template: Handlebars.compile(html)
            });
            return _self;
        };

        _self.renderRetailerLookup = function(options) {
            _retailerLookupMenu.render({
                options: options
            }).show();
            _retailerLookupMenu.init(function(option) {
                handleRetailerLookupItemSelectEvent(option);
            });
        };

        _self.renderClientLookup = function(options) {
            _clientLookupMenu.render({
                options: options
            }).show();
            _clientLookupMenu.init(function(option) {
                $("#projectClient").val(option.value).attr("data-id", option.key);
                _clientLookupMenu.hide();
            });
        };

        _self.renderApproverLookup = function(options) {
            _approverLookupMenu.render({
                options: options
            }).show();
            _approverLookupMenu.init(function(option) {
                $("#projectApprover").val(option.value).attr("data-id", option.key);
                _approverLookupMenu.hide();
            });
        };

        _self.renderCreateProject = function(projectType) {
            var template = _.find(_templates, function(t) {
                return t.id === projectType.projectTypeId;
            });
            var html = template.template(projectType);
            $("#formWizard").empty().html(html);
            flipDashboardAndFormWizard();
            $('#formWizard').on("focus", ".cm-form input[data-role='date']", function(e) {
                e.preventDefault();
                var id = $(this).attr("id");
                $(["#", id, "Picker"].join("")).toggleClass('hide');
            }).on("blur", ".cm-form input[data-role='date']", function(e) {
                e.preventDefault();
                var id = $(this).attr("id");
                $(["#", id, "Picker"].join("")).toggleClass('hide');
            });
        }

        function handleRetailerLookupItemSelectEvent(option) {
            $("#projectRetailer").val(option.value).attr("data-id", option.key);
            _retailerLookupMenu.hide();
        }

        function handleLookupKeyDown(e) {

        }
        //todo need to handle keyup event
        function initFormWizard() {
            $("#formWizard").on("click", ".breadcrumb > li > a", function(e) {
                e.preventDefault();
                flipDashboardAndFormWizard();
            });
            $("#formWizard").on("click", ".cm-form-footer button", function(e) {
                e.preventDefault();
                if ($(this).val() === "0") {
                    flipDashboardAndFormWizard();
                } else {
                    _app.router().route("project/saveProject");
                }
            });
            //todo: init lookup button (typehead)
            $("#formWizard").on("click", "input#projectRetailer", function(e) {
                e.preventDefault();
                _app.router().route("project/lookupRetailers");
            }).on("blur", "input#projectRetailer", function(e) {
                e.preventDefault();
                if (_retailerLookupMenu.isMouseOver()) {
                    return;
                }
                _retailerLookupMenu.hide();
            }).on("keyup", "input#projectRetailer", function(e) {
                e.preventDefault();
                handleLookupKeyDown(e);
            }).
            on("click", "input#projectClient", function(e) {
                e.preventDefault();
                _app.router().route("project/lookupClients");
            }).on("blur", "input#projectClient", function(e) {
                e.preventDefault();
                if (_clientLookupMenu.isMouseOver()) {
                    return;
                }
                _clientLookupMenu.hide();
            }).on("keyup", "", function(e) {
                e.preventDefault();
                handleLookupKeyDown(e);
            }).
            on("click", "input#projectApprover", function(e) {
                e.preventDefault();
                _app.router().route("project/lookupApprovers");
            }).on("blur", "input#projectApprover", function(e) {
                e.preventDefault();
                if (_approverLookupMenu.isMouseOver()) {
                    return;
                }
                _approverLookupMenu.hide();
            }).on("keyup", "", function(e) {
                e.preventDefault();
                handleLookupKeyDown(e);
            });
        }

        _self.addEvent(function() {
            initFormWizard();
        });

        return _self;
    };

    var Controller = function(id) {
        var self = Object.create(_app.createController(id));

        self.gotoCreateProject = function(option) {
            var v = self.view,
                m = self.model,
                type = {
                    projectTypeId: option.key,
                    projectType: option.value
                }
            if (v.uiLoaded(type.projectTypeId)) {
                v.renderCreateProject(type);
            } else {
                m.getCreateProjectUI(type.projectType)
                    .done(function(html) {
                        v.setUI(type.projectTypeId, html)
                            .renderCreateProject(type);
                    })
                    .fail(function(err) {
                        alert(err);
                    });
            }
        };

        self.gotoEditProject = function() {
            //load page fields and render page for project editting
        }

        self.save = function(formData) {
            var data, m = self.model, v  = self.view;
            if (!v.validateFormData()){ return; }
            data = v.getFormData();
            m.saveProject(data)
             .done( function (result) {
                window.location.href = "/apex/ProjectView?id=" + result
             }).fail ( function (err) {
                alert(err);
             });
        };

        self.cancel = function() {
            _app.router().route("dashboard/goHome");
        };

        self.lookupRetailers = function(query) {
            var m = self.model,
                v = self.view;
            m.getRetailers(query && query.retailer)
                .done(function(result) {
                    v.renderRetailerLookup(result);
                })
                .fail(function(err) {
                    alert(err);
                });
        };

        self.lookupApprovers = function(query) {
            var m = self.model,
                v = self.view;
            m.getApprovers(query && query.client)
                .done(function(result) {
                    v.renderApproverLookup(result);
                })
                .fail(function(err) {
                    alert(err);
                });
        };

        self.lookupClients = function(query) {
            var m = self.model,
                v = self.view;
            m.getClients(query && query.client)
                .done(function(result) {
                    v.renderClientLookup(result);
                })
                .fail(function(err) {
                    alert(err);
                });
        };

        return self;
    };

    _app.addOnLoadEventListener(function() {
        var controllerId = "project";
        _app.registerMVC(new Model(), new Viewer(), new Controller(controllerId));
        _app.router().addRoute("project/gotoCreateProject", controllerId, "gotoCreateProject")
            .addRoute("project/gotoEditProject", controllerId, "gotoEditProject")
            .addRoute("project/cancel", controllerId, "cancel")
            .addRoute("project/saveProject", controllerId, "save")
            .addRoute("project/lookupRetailers", controllerId, "lookupRetailers")
            .addRoute("project/lookupApprovers", controllerId, "lookupApprovers")
            .addRoute("project/lookupClients", controllerId, "lookupClients");
    });

})();
